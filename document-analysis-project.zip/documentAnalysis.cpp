//Implementation file for Document Analysis

#include "documentAnalysis.h"
#include <iostream>
#include <cstddef> //where NULL is defined
#include <fstream> 
#include <algorithm>

using namespace std;

//Default Constructor
documentAnalysis::documentAnalysis(){
    root = NULL; //Sets root equal to NULL
}

//Adds a new node containing the given word.
void documentAnalysis::update(string word){
    if(foundWord(root, word) == false)
       insert(root, word); //Inserts Word if Not in Tree
    else
       updateCount(root, word); //Update Count of Word
}

//Reads all the words in the input file and adds them.
void documentAnalysis::analyze(string filename){
    string word = filename;
    ifstream file;
    file.open(filename);
    //Checks to ensure file was opened correctly
    if(!file){
        cerr << "Unable to open file.";
        exit(1);
    }
    while(file >> word){
        //Removes Unwanted Punctuatuion
        word.erase(remove(word.begin(), word.end(), '.'), word.end());
        word.erase(remove(word.begin(), word.end(), '!'), word.end());
        word.erase(remove(word.begin(), word.end(), '?'), word.end());
        word.erase(remove(word.begin(), word.end(), ','), word.end());
        word.erase(remove(word.begin(), word.end(), ';'), word.end());
        word.erase(remove(word.begin(), word.end(), ':'), word.end());
        //Lowercase each word 
        toLower(word);
        update(word); //Updates Tree
    }
}

//Displays all the words and their frequencies
void documentAnalysis::print(){
    printWords(root);
}

//Displays the word that has the highest frequency
void documentAnalysis::maxFrequency(){
    string word;
    int count;
    word = max(root, word, count);
    frequency(word);
}

//Displays the frequency of the given word 
void documentAnalysis::frequency(string word){
    findFreq(root, word);
}

//Helper Function to Update. 
Node* documentAnalysis::insert(Node *&root, string word){
    if (root == NULL){
        Node *node = new Node;
        node->left = NULL;
        node->right = NULL;
        node->word = word;
        node->count = 1;
        root = node;
    }
    else if (word < root->word)
        root->left = insert(root->left, word); //Inserts to the Left
    else
        root->right = insert(root->right, word); //Inserts to the Right
    return root;
}

//Helper Function to Update Count.
void documentAnalysis::updateCount(Node* root, string word){
    int count = root->count;
    if (word == root-> word)
        root->count = count + 1;
    else if (word < root->word)
        updateCount(root->left, word);
    else
        updateCount(root->right, word);
}

//Check to see if word exists in tree already.
bool documentAnalysis::foundWord(Node* root, string word){
    bool wordFound;
    if(root!=NULL) {
        if (word == root->word){
            wordFound = true;
        }
        else if (word > root->word){ //Checks Right Subtree
            wordFound = foundWord(root->right,word);
        }
        else if (word < root->word){
            wordFound = foundWord(root->left,word); //Checks Left Subtree
        }
        else {
            wordFound = false;
    }
   }
   return wordFound;
}

//Lowercase each word
void documentAnalysis::toLower(string &word){
    int length = 0;
    //Lowercase Each Letter in a given word
    while(length < word.length()){
        word[length] = tolower(word[length]);
        length++;
    }
}

//Print Helper Function
void documentAnalysis::printWords(Node *root){
    if(root!= NULL){
        printWords(root->left);//Print Left Subtree
        cout << endl << root->word << " Frequency: " << root->count;
        printWords(root->right);//Print Right Subtree
    }
}

//Find frequency of a given word
void documentAnalysis::findFreq(Node *root, string word){
    //Searches tree for a word and displays the frequency
    if(root!= NULL){
        if(word == root->word)
            cout << endl << root->word << "'s frequency: " << root->count;
    
        else if (word < root->word)
            findFreq(root->left, word);
        else
            findFreq(root->right, word);
    }
    else
        cout << endl << "Word not found!";
}
////Shows the word that occurs the most
string documentAnalysis::max(Node *root, string &word, int &count){
    //Searches the tree to find the highest frequency
    if(root!= NULL){
        if (root->count > count){
            word = root->word;
            count = root->count;}
        
        max(root->left, word, count);
        max(root->right, word, count);
    }
    
    return word;
    
}
