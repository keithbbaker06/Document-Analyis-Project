//Header file for Document Analysis

#include <string>

using namespace std;

//Define a Node for BST

struct Node {
    string word; //Holds the Word
    long count; //Holds the count
    Node* left; //Left Node
    Node* right; //Right Node
};


class documentAnalysis {
    public:
        //Default Constructor
        documentAnalysis();
        //Adds a new node containing the given word
        void update(string word);
        //Reads all the words in the input file and adds them
        void analyze(string filename);
        //Displays all the words and their frequencies
        void print();
        //Displays the word that has the highest frequency
        void maxFrequency();
        //Displays the frequency of the given word 
        void frequency(string word);
    private:
        Node* root;
        //Helper function to update tree
        Node* insert(Node *&root, string word);
        //Helper Function to Update count
        void updateCount(Node* root, string word);
        //Helper function to see if word exist in tree already
        bool foundWord(Node* root, string word);
        //Function to make all words lower case
        void toLower(string &word);
        //Function to print
        void printWords(Node* root);
        //Find frequency of a given word
        void findFreq(Node* root, string word);
        //Shows the word that occurs the most
        string max(Node *root, string &word, int &count);

};

