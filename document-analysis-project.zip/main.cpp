/*  BST Document Analysis Program. 
    Program will take a text file as input and determine how many times each
    unique word appears in that text file. Takes input from Command Line
*/

#include <iostream>
#include "documentAnalysis.h"


int main(int argc, char* argv[]){
    documentAnalysis file1;
    string choice; //Will hold the user's choice
    
    file1.analyze(argv[1]);
    file1.print();
    cout << "\nThe word that appeared the most.\n";
    file1.maxFrequency();
    
    do {
        cout << "\nEnter a word and the frequency will be shown. (Enter ""Q"" to exit.)\n";
        cin >> choice;
        if(choice!="Q")
            file1.frequency(choice);
    }
    while(choice!="Q");
}